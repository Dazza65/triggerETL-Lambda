zip -r triggerETL.zip .
